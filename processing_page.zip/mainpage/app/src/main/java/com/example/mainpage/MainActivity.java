package com.example.mainpage;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    String Title[] = {"早餐","甜點","蔬菜","水果","食物"};
    String sec[] = {"吃膩外面的油膩早餐嗎？蛋餅、三明治、吐司、麵包夾上新鮮配料再打顆蛋，美味早餐自己做！",
            "點心（Dessert）通常是指是西餐正餐的最後一道甜味菜品，也可以說是西方人在餐後食用的甜味食物。",
            "蔬菜，是指可以用来做菜、烹饪成为食品的，除了穀物以外的其他植物（多属于草本）生活中所指的的蔬菜。",
            "數百種安心食材任妳挑選，一鍵下單超便利，雙北當日配、全台隔日配，24h買菜快速到貨，買菜不用苦苦等待。",
            "食物（英文：Food）是指能夠滿足機體正常生理和生化能量需求，並能延續正常壽命的物質。對人體而言，能夠滿足人的正常生活活動需求並利於壽命延長的物質稱之為食物。"};

    int image[] = {R.drawable.coco,R.drawable.mar,R.drawable.der,R.drawable.su,R.drawable.pabu};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listview);


        MyAdapter myAdapter = new MyAdapter(this,Title,sec,image);
        listView.setAdapter(myAdapter);

    }
    class MyAdapter extends ArrayAdapter<String>{

        Context context;
        String rTitle[];
        String rsec[];
        int rimage[];

        MyAdapter (Context context,String title[],String sec[],int image[]){
            super(context,R.layout.layout,R.id.otitle,title);
            this.context = context;
            this.rTitle = title;
            this.rsec = sec;
            this.rimage = image;
        }

        @NonNull
        @Override
        public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
            LayoutInflater layoutInflater = (LayoutInflater)getApplicationContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);

            View row = layoutInflater.inflate(R.layout.layout,parent,false);
            ImageView images = row.findViewById(R.id.image);
            TextView textView = row.findViewById(R.id.otitle);
            TextView textView1 = row.findViewById(R.id.ttitle);

            images.setImageResource(rimage[position]);
            textView.setText(rTitle[position]);
            textView1.setText(rsec[position]);

            return row;
        }
    }
}